# Shimmer Jewelry Product Catalog

## Brand Information
- **Brand Name**: Shimmer
- **Tagline**: "Bring a Touch of Shimmer in your everyday."
- **Origin**: Exclusive designs in Malaysia

## Products

### 1. Essential Lines Bracelet
- **Materials**: 925 silver & Shimmer Diamond
- **Bracelet Size**: 
  - 15cm (XS)
  - 16cm (S)
  - 17cm (M)
  - 18cm (L)
- **Diamond Size**: 
  - 4mm (0.3ct)
  - 5mm (0.6ct)
- **Price**:
  - 15cm, 4mm: RM328
  - 16cm, 4mm: Not specified
  - 17cm, 4mm: RM358
  - 18cm, 4mm: Not specified
  - 15cm, 5mm: Not specified
  - 16cm, 5mm: RM348
  - 17cm, 5mm: Not specified
  - 18cm, 5mm: RM378

### 2. Classic Diamond Drop Pendant (NO. 003)
- **Materials**: Not specified in frames
- **Design**: Bow-shaped pendant with diamond drop
- **Price**: Not specified in frames

### 3. Classic Oval Diamond Ring (NO. 005)
- **Materials**: Not specified in frames
- **Design**: Ring with oval center diamond surrounded by smaller diamonds
- **Price**: Not specified in frames

### 4. Traffic Light Diamond Ring (NO. 006)
- **Materials**: Appears to be gold setting with colored gemstones
- **Design**: Ring with multiple colored gemstones (red, green, and possibly other colors)
- **Price**: Not specified in frames

### 5. Classic Diamond Ring (NO. 008)
- **Materials**: Not specified in frames
- **Design**: Multiple diamond pieces including what appears to be a bracelet or watch and colored gemstones
- **Price**: Not specified in frames

### 6. Classic Diamond Drop Pendant (NO. 009)
- **Materials**: Not specified in frames
- **Design**: Diamond pendant with multiple stones
- **Price**: Not specified in frames

### 7. Butterfly Silhouette Ring
- **Materials**: Copper & Swarovski Diamond
- **Size**: Free Size (Adjustable)
- **Price**: RM 68
- **Note**: Exclusive design in Malaysia
- **Design**: Butterfly-shaped ring with colored gemstones

## Notes on Gold Products
While the initial request mentioned gold rings and gold jambu products, the video catalog primarily shows silver, copper, and unspecified metal jewelry with diamonds and gemstones. Some products (like the Traffic Light Diamond Ring) appear to have gold settings, but are not explicitly labeled as gold in the frames analyzed.
